<?php
require_once 'config/database.php';

$db = getDatabase();

// Cek total pembelian
$result = $db->select('SELECT COUNT(*) as total FROM pembelian');
echo "Total pembelian: " . $result[0]['total'] . "\n";

// Cek data pembelian terbaru
$recent = $db->select('SELECT * FROM pembelian ORDER BY created_at DESC LIMIT 5');
echo "\nData pembelian terbaru:\n";
foreach($recent as $row) {
    echo "ID: " . $row['id'] . ", PO: " . $row['nomor_po'] . ", Vendor: " . $row['vendor_id'] . ", Total: " . $row['total_amount'] . ", Status: " . $row['status_pembelian'] . "\n";
}

// Cek tabel vendor
$vendors = $db->select('SELECT * FROM vendor ORDER BY id');
echo "\nData vendor:\n";
foreach($vendors as $vendor) {
    echo "ID: " . $vendor['id'] . ", Nama: " . $vendor['nama_vendor'] . ", Status: " . $vendor['status'] . "\n";
}

// Cek tabel users
$users = $db->select('SELECT id, username, nama_lengkap FROM users ORDER BY id');
echo "\nData users:\n";
foreach($users as $user) {
    echo "ID: " . $user['id'] . ", Username: " . $user['username'] . ", Nama: " . $user['nama_lengkap'] . "\n";
}

// Cek apakah tabel hutang ada
echo "\nCek tabel hutang:\n";
try {
    $hutang_check = $db->select('SHOW TABLES LIKE "hutang"');
    if (count($hutang_check) > 0) {
        echo "Tabel hutang ada\n";
        $hutang_data = $db->select('SELECT COUNT(*) as total FROM hutang');
        echo "Total data hutang: " . $hutang_data[0]['total'] . "\n";
    } else {
        echo "Tabel hutang TIDAK ADA\n";
    }
} catch(Exception $e) {
    echo "Error mengecek tabel hutang: " . $e->getMessage() . "\n";
}

// Test query pembelian seperti di halaman pembelian.php
echo "\nTest query pembelian:\n";
try {
    $test_query = "
        SELECT 
            p.*,
            v.nama_vendor,
            v.kode_vendor,
            u.nama_lengkap as user_name,
            COALESCE(h.jumlah_hutang, 0) as total_hutang
        FROM pembelian p
        JOIN vendor v ON p.vendor_id = v.id
        JOIN users u ON p.user_id = u.id
        LEFT JOIN hutang h ON p.id = h.pembelian_id AND h.status != 'lunas'
        ORDER BY p.tanggal_pembelian DESC
        LIMIT 5
    ";
    $test_result = $db->select($test_query);
    echo "Query berhasil, hasil: " . count($test_result) . " records\n";
    foreach($test_result as $row) {
        echo "PO: " . $row['nomor_po'] . ", Vendor: " . $row['nama_vendor'] . ", User: " . $row['user_name'] . "\n";
    }
} catch(Exception $e) {
    echo "Error query: " . $e->getMessage() . "\n";
}

// Cek struktur tabel pembelian
echo "\nStruktur tabel pembelian:\n";
$structure = $db->select('DESCRIBE pembelian');
foreach($structure as $col) {
    echo $col['Field'] . " - " . $col['Type'] . " - " . $col['Null'] . " - " . $col['Key'] . "\n";
}
?>