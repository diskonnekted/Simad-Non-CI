<?php
// Script untuk memeriksa tabel yang tersedia dalam database

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'simadorbitdev_simad';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Koneksi database berhasil\n";
    
    echo "\nDaftar tabel dalam database $database:\n";
    $result = $pdo->query('SHOW TABLES');
    while($row = $result->fetch()) {
        echo "- " . $row[0] . "\n";
    }
    
} catch(PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>