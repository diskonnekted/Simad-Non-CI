<?php
require_once 'config/auth.php';
require_once 'config/database.php';

// Inisialisasi koneksi database
$pdo = getDBConnection();

// Cek autentikasi
AuthStatic::requireLogin();

// Fungsi format Rupiah
function formatRupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

// Handle pembayaran piutang
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'bayar' && AuthStatic::hasRole(['admin', 'finance'])) {
        $piutang_id = (int)$_POST['piutang_id'];
        $jumlah_bayar = (float)$_POST['jumlah_bayar'];
        $metode_pembayaran = $_POST['metode_pembayaran'];
        $keterangan = $_POST['keterangan'] ?? '';
        
        try {
            $pdo->beginTransaction();
            
            // Get piutang info
            $stmt = $pdo->prepare("SELECT * FROM piutang WHERE id = ?");
            $stmt->execute([$piutang_id]);
            $piutang = $stmt->fetch();
            
            if (!$piutang || $jumlah_bayar <= 0 || $jumlah_bayar > $piutang['sisa_piutang']) {
                throw new Exception('Data pembayaran tidak valid');
            }
            
            // Insert pembayaran
            $stmt = $pdo->prepare("
                INSERT INTO pembayaran_piutang (piutang_id, jumlah_bayar, metode_pembayaran, keterangan, tanggal_bayar, created_by) 
                VALUES (?, ?, ?, ?, NOW(), ?)
            ");
            $stmt->execute([$piutang_id, $jumlah_bayar, $metode_pembayaran, $keterangan, AuthStatic::getUserId()]);
            
            // Update sisa piutang
            $sisa_baru = $piutang['sisa_piutang'] - $jumlah_bayar;
            $status_baru = $sisa_baru <= 0 ? 'lunas' : 'aktif';
            
            $stmt = $pdo->prepare("UPDATE piutang SET sisa_piutang = ?, status = ? WHERE id = ?");
            $stmt->execute([$sisa_baru, $status_baru, $piutang_id]);
            
            $pdo->commit();
            $success_message = 'Pembayaran berhasil dicatat';
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $error_message = 'Gagal mencatat pembayaran: ' . $e->getMessage();
        }
    }
    
    if ($_POST['action'] === 'bayar_hutang' && AuthStatic::hasRole(['admin', 'finance'])) {
        $hutang_id = (int)$_POST['hutang_id'];
        $jumlah_bayar = (float)$_POST['jumlah_bayar'];
        $metode_pembayaran = $_POST['metode_pembayaran'];
        $keterangan = $_POST['keterangan'] ?? '';
        
        try {
            $pdo->beginTransaction();
            
            // Get hutang info
            $stmt = $pdo->prepare("SELECT * FROM hutang WHERE id = ?");
            $stmt->execute([$hutang_id]);
            $hutang = $stmt->fetch();
            
            if (!$hutang || $jumlah_bayar <= 0 || $jumlah_bayar > $hutang['sisa_hutang']) {
                throw new Exception('Data pembayaran tidak valid');
            }
            
            // Insert pembayaran
            $stmt = $pdo->prepare("
                INSERT INTO pembayaran_hutang (hutang_id, jumlah_bayar, metode_pembayaran, keterangan, tanggal_bayar, created_by) 
                VALUES (?, ?, ?, ?, NOW(), ?)
            ");
            $stmt->execute([$hutang_id, $jumlah_bayar, $metode_pembayaran, $keterangan, AuthStatic::getUserId()]);
            
            // Update sisa hutang
            $sisa_baru = $hutang['sisa_hutang'] - $jumlah_bayar;
            $status_baru = $sisa_baru <= 0 ? 'lunas' : 'aktif';
            
            $stmt = $pdo->prepare("UPDATE hutang SET sisa_hutang = ?, status = ? WHERE id = ?");
            $stmt->execute([$sisa_baru, $status_baru, $hutang_id]);
            
            $pdo->commit();
            $success_message = 'Pembayaran hutang berhasil dicatat';
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $error_message = 'Gagal mencatat pembayaran hutang: ' . $e->getMessage();
        }
    }
}

// Update status piutang berdasarkan tanggal jatuh tempo
$stmt = $pdo->prepare("
    UPDATE piutang 
    SET status = CASE 
        WHEN tanggal_jatuh_tempo < CURDATE() AND status = 'belum_jatuh_tempo' THEN 'terlambat'
        WHEN DATEDIFF(tanggal_jatuh_tempo, CURDATE()) <= 7 AND status = 'belum_jatuh_tempo' THEN 'mendekati_jatuh_tempo'
        ELSE status 
    END
    WHERE status IN ('belum_jatuh_tempo', 'mendekati_jatuh_tempo')
");
$stmt->execute();

// Filter parameters
$search = $_GET['search'] ?? '';
$desa_filter = $_GET['desa'] ?? '';
$status_filter = $_GET['status'] ?? '';
$status_pembayaran_filter = $_GET['status_pembayaran'] ?? '';
$tanggal_dari = $_GET['tanggal_dari'] ?? '';
$tanggal_sampai = $_GET['tanggal_sampai'] ?? '';
$sort = $_GET['sort'] ?? 'tanggal_jatuh_tempo';
$order = $_GET['order'] ?? 'asc';
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

// Build WHERE clause
$where_conditions = [];
$params = [];

if ($search) {
    $where_conditions[] = "(t.invoice_number LIKE ? OR c.nama_desa LIKE ? OR u.nama LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

if ($desa_filter) {
    $where_conditions[] = "c.nama_desa = ?";
    $params[] = $desa_filter;
}

if ($status_filter) {
    $where_conditions[] = "p.status = ?";
    $params[] = $status_filter;
}

if ($status_pembayaran_filter) {
    if ($status_pembayaran_filter === 'lunas') {
        $where_conditions[] = "p.status = 'lunas'";
    } elseif ($status_pembayaran_filter === 'belum_lunas') {
        $where_conditions[] = "p.status IN ('belum_jatuh_tempo', 'mendekati_jatuh_tempo', 'terlambat')";
    }
}

if ($tanggal_dari) {
    $where_conditions[] = "p.tanggal_jatuh_tempo >= ?";
    $params[] = $tanggal_dari;
}

if ($tanggal_sampai) {
    $where_conditions[] = "p.tanggal_jatuh_tempo <= ?";
    $params[] = $tanggal_sampai;
}

$where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get total count
$count_query = "
    SELECT COUNT(*) as total
    FROM piutang p
    JOIN transaksi t ON p.transaksi_id = t.id
    JOIN desa c ON t.desa_id = c.id
    JOIN users u ON t.user_id = u.id
    $where_clause
";
$stmt = $pdo->prepare($count_query);
$stmt->execute($params);
$total_records = $stmt->fetch()['total'];
$total_pages = ceil($total_records / $limit);

// Get piutang data
$valid_sorts = ['invoice_number', 'nama_customer', 'tanggal_jatuh_tempo', 'jumlah_piutang', 'status'];
$sort_column = in_array($sort, $valid_sorts) ? $sort : 'tanggal_jatuh_tempo';
$order_direction = strtoupper($order) === 'DESC' ? 'DESC' : 'ASC';

$sort_mapping = [
    'invoice_number' => 't.invoice_number',
    'nama_customer' => 'c.nama_desa',
    'tanggal_jatuh_tempo' => 'p.tanggal_jatuh_tempo',
    'jumlah_piutang' => 'p.jumlah_piutang',
    'status' => 'p.status'
];

$order_by = $sort_mapping[$sort_column] ?? 'p.tanggal_jatuh_tempo';

$query = "
    SELECT p.*, t.id as nomor_transaksi, t.tanggal_transaksi, 
           c.nama_desa as nama_customer, c.nama_desa as desa, c.no_hp_kepala_desa as no_hp,
           u.nama_lengkap as sales_name,
           DATEDIFF(p.tanggal_jatuh_tempo, CURDATE()) as hari_tersisa
    FROM piutang p
    JOIN transaksi t ON p.transaksi_id = t.id
    JOIN desa c ON t.desa_id = c.id
    JOIN users u ON t.user_id = u.id
    $where_clause
    ORDER BY $order_by $order_direction
    LIMIT $limit OFFSET $offset
";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$piutang_list = $stmt->fetchAll();

// Get desa list for filter
$stmt = $pdo->query("SELECT DISTINCT nama_desa FROM desa WHERE nama_desa IS NOT NULL AND nama_desa != '' ORDER BY nama_desa");
$desa_list = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Get statistics
$stats_query = "
    SELECT 
        COUNT(*) as total_piutang,
        SUM(CASE WHEN p.status = 'belum_jatuh_tempo' THEN 1 ELSE 0 END) as belum_jatuh_tempo,
        SUM(CASE WHEN p.status = 'lunas' THEN 1 ELSE 0 END) as lunas,
        SUM(CASE WHEN p.status = 'mendekati_jatuh_tempo' THEN 1 ELSE 0 END) as mendekati_jatuh_tempo,
        SUM(CASE WHEN p.status = 'terlambat' THEN 1 ELSE 0 END) as terlambat,
        SUM(p.jumlah_piutang) as total_nilai_piutang
    FROM piutang p
    JOIN transaksi t ON p.transaksi_id = t.id
    JOIN desa c ON t.desa_id = c.id
    JOIN users u ON t.user_id = u.id
    $where_clause
";
$stmt = $pdo->prepare($stats_query);
$stmt->execute($params);
$piutang_stats = $stmt->fetch();

// Get hutang data
$hutang_query = "
    SELECT h.*, pb.nomor_po, pb.tanggal_pembelian,
           v.nama_vendor, v.nama_kontak, v.no_hp,
           DATEDIFF(h.tanggal_jatuh_tempo, CURDATE()) as hari_tersisa
    FROM hutang h
    JOIN pembelian pb ON h.pembelian_id = pb.id
    JOIN vendor v ON pb.vendor_id = v.id
    WHERE h.status = 'aktif'
    ORDER BY h.tanggal_jatuh_tempo ASC
    LIMIT 10
";
$stmt = $pdo->query($hutang_query);
$hutang_list = $stmt->fetchAll();

// Get hutang statistics
$hutang_stats_query = "
    SELECT 
        COUNT(*) as total_hutang,
        SUM(h.jumlah_hutang) as total_nilai_hutang
    FROM hutang h
    WHERE h.status = 'aktif'
";
$stmt = $pdo->query($hutang_stats_query);
$hutang_stats = $stmt->fetch();

// Helper functions
function getStatusText($status) {
    $status_texts = [
        'belum_jatuh_tempo' => 'Belum Jatuh Tempo',
        'lunas' => 'Lunas',
        'mendekati_jatuh_tempo' => 'Mendekati Jatuh Tempo',
        'terlambat' => 'Terlambat',
        'dibatalkan' => 'Dibatalkan'
    ];
    return $status_texts[$status] ?? $status;
}

function getStatusBadge($status) {
    $badges = [
        'belum_jatuh_tempo' => 'bg-blue-100 text-blue-800',
        'lunas' => 'bg-green-100 text-green-800',
        'mendekati_jatuh_tempo' => 'bg-yellow-100 text-yellow-800',
        'terlambat' => 'bg-red-100 text-red-800',
        'dibatalkan' => 'bg-gray-100 text-gray-800'
    ];
    return $badges[$status] ?? 'bg-gray-100 text-gray-800';
}

function getJatuhTempoBadge($hari_tersisa, $status) {
    if ($status === 'lunas') {
        return '<span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">Lunas</span>';
    }
    
    if ($hari_tersisa < 0) {
        $hari_terlambat = abs($hari_tersisa);
        return '<span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">Terlambat ' . $hari_terlambat . ' hari</span>';
    } elseif ($hari_tersisa == 0) {
        return '<span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-orange-100 text-orange-800">Jatuh tempo hari ini</span>';
    } elseif ($hari_tersisa <= 7) {
        return '<span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">' . $hari_tersisa . ' hari lagi</span>';
    } else {
        return '<span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">' . $hari_tersisa . ' hari lagi</span>';
    }
}

function getSortUrl($column, $current_sort, $current_order) {
    $new_order = ($current_sort === $column && $current_order === 'asc') ? 'desc' : 'asc';
    $params = $_GET;
    $params['sort'] = $column;
    $params['order'] = $new_order;
    return '?' . http_build_query($params);
}

function getSortIcon($column, $current_sort, $current_order) {
    if ($current_sort !== $column) {
        return '<i class="fas fa-sort text-gray-400"></i>';
    }
    return $current_order === 'asc' ? 
        '<i class="fas fa-sort-up text-primary-600"></i>' : 
        '<i class="fas fa-sort-down text-primary-600"></i>';
}

$page_title = 'Manajemen Piutang & Hutang';
require_once 'layouts/header.php';
?>

<div class="min-h-screen bg-gray-50 py-4">
    <div class="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6">
        <!-- Header Section -->
        <div class="mb-6">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 class="text-2xl sm:text-3xl font-bold text-gray-900">Manajemen Piutang & Hutang</h1>
                    <p class="mt-2 text-sm text-gray-600">Kelola piutang pelanggan dan hutang vendor</p>
                </div>
                <div class="mt-4 sm:mt-0 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
                    <button onclick="exportData()" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-colors">
                        <i class="fas fa-download mr-2"></i> Export Excel
                    </button>
                    <a href="transaksi-add.php" class="inline-flex items-center px-4 py-2 bg-primary-600 text-white text-sm font-medium rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-colors">
                        <i class="fas fa-plus mr-2"></i> Transaksi Baru
                    </a>
                </div>
            </div>
        </div>

        <!-- Alert Messages -->
        <?php if (isset($success_message)): ?>
        <div class="mb-6 bg-green-50 border border-green-200 rounded-lg p-4">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-check-circle text-green-400"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-green-800"><?= htmlspecialchars($success_message) ?></p>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
        <div class="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-exclamation-circle text-red-400"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-red-800"><?= htmlspecialchars($error_message) ?></p>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Filter Section -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 mb-5">
            <div class="p-4">
                <form method="GET" class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <!-- Search -->
                        <div>
                            <label for="search" class="block text-sm font-medium text-gray-700 mb-1">Pencarian</label>
                            <input type="text" id="search" name="search" value="<?= htmlspecialchars($search) ?>" 
                                   placeholder="Cari invoice, customer, sales..." 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
                        </div>

                        <!-- Desa Filter -->
                        <div>
                            <label for="desa" class="block text-sm font-medium text-gray-700 mb-1">Desa</label>
                            <select id="desa" name="desa" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
                                <option value="">Semua Desa</option>
                                <?php foreach ($desa_list as $desa): ?>
                                <option value="<?= htmlspecialchars($desa) ?>" <?= $desa_filter === $desa ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($desa) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Status Filter -->
                        <div>
                            <label for="status" class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                            <select id="status" name="status" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
                                <option value="">Semua Status</option>
                                <option value="belum_jatuh_tempo" <?= $status_filter === 'belum_jatuh_tempo' ? 'selected' : '' ?>>Belum Jatuh Tempo</option>
                                <option value="lunas" <?= $status_filter === 'lunas' ? 'selected' : '' ?>>Lunas</option>
                                <option value="mendekati_jatuh_tempo" <?= $status_filter === 'mendekati_jatuh_tempo' ? 'selected' : '' ?>>Mendekati Jatuh Tempo</option>
                                <option value="terlambat" <?= $status_filter === 'terlambat' ? 'selected' : '' ?>>Terlambat</option>
                            </select>
                        </div>

                        <!-- Status Pembayaran Filter -->
                        <div>
                            <label for="status_pembayaran" class="block text-sm font-medium text-gray-700 mb-1">Status Pembayaran</label>
                            <select id="status_pembayaran" name="status_pembayaran" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
                                <option value="">Semua Status</option>
                                <option value="lunas" <?= $status_pembayaran_filter === 'lunas' ? 'selected' : '' ?>>Lunas</option>
                                <option value="belum_lunas" <?= $status_pembayaran_filter === 'belum_lunas' ? 'selected' : '' ?>>Belum Lunas</option>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <!-- Tanggal Dari -->
                        <div>
                            <label for="tanggal_dari" class="block text-sm font-medium text-gray-700 mb-1">Tanggal Dari</label>
                            <input type="date" id="tanggal_dari" name="tanggal_dari" value="<?= htmlspecialchars($tanggal_dari) ?>" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
                        </div>

                        <!-- Tanggal Sampai -->
                        <div>
                            <label for="tanggal_sampai" class="block text-sm font-medium text-gray-700 mb-1">Tanggal Sampai</label>
                            <input type="date" id="tanggal_sampai" name="tanggal_sampai" value="<?= htmlspecialchars($tanggal_sampai) ?>" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
                        </div>
                    </div>

                    <div class="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
                        <button type="submit" class="inline-flex items-center px-4 py-2 bg-primary-600 text-white text-sm font-medium rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-colors">
                            <i class="fas fa-search mr-2"></i> Filter
                        </button>
                        <a href="piutang.php" class="inline-flex items-center px-4 py-2 border border-gray-300 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors">
                            <i class="fas fa-times mr-2"></i> Reset
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Piutang Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-file-invoice text-blue-600"></i>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-600">Total Piutang</p>
                        <p class="text-2xl font-semibold text-gray-900"><?= number_format($piutang_stats['total_piutang'] ?? 0) ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-clock text-yellow-600"></i>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-600">Belum Jatuh Tempo</p>
                        <p class="text-2xl font-semibold text-blue-600"><?= number_format($piutang_stats['belum_jatuh_tempo'] ?? 0) ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-check-circle text-green-600"></i>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-600">Lunas</p>
                        <p class="text-2xl font-semibold text-green-600"><?= number_format($piutang_stats['lunas'] ?? 0) ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-exclamation-triangle text-red-600"></i>
                        </div>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-600">Terlambat</p>
                        <p class="text-2xl font-semibold text-red-600"><?= number_format($piutang_stats['terlambat'] ?? 0) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Piutang Table -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 mb-6">
            <div class="px-4 py-3 border-b border-gray-200 flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h3 class="text-lg font-semibold text-gray-900">Daftar Piutang</h3>
                    <p class="text-sm text-gray-600 mt-1"><?= number_format($total_records) ?> piutang ditemukan</p>
                </div>
                <div class="mt-4 sm:mt-0">
                    <span class="text-sm text-gray-600">
                        Total Nilai: <span class="font-semibold text-blue-600"><?= formatRupiah($piutang_stats['total_nilai_piutang'] ?? 0) ?></span>
                    </span>
                </div>
            </div>

            <?php if (empty($piutang_list)): ?>
            <div class="text-center py-12">
                <div class="w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-file-invoice text-gray-400 text-3xl"></i>
                </div>
                <h4 class="text-lg font-semibold text-gray-900 mb-2">Tidak ada piutang ditemukan</h4>
                <p class="text-gray-600 mb-6">Belum ada transaksi dengan sistem tempo yang menghasilkan piutang.</p>
                <button onclick="location.href='transaksi-add.php'" class="inline-flex items-center px-4 py-2 bg-primary-600 text-white text-sm font-medium rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-colors">
                    <i class="fas fa-plus mr-2"></i> Buat Transaksi Pertama
                </button>
            </div>
            <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th onclick="location.href='<?= getSortUrl('invoice_number', $sort, $order) ?>'" 
                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors">
                                <div class="flex items-center space-x-1">
                                    <span>Invoice</span>
                                    <?= getSortIcon('invoice_number', $sort, $order) ?>
                                </div>
                            </th>
                            <th onclick="location.href='<?= getSortUrl('nama_customer', $sort, $order) ?>'" 
                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors">
                                <div class="flex items-center space-x-1">
                                    <span>Customer</span>
                                    <?= getSortIcon('nama_customer', $sort, $order) ?>
                                </div>
                            </th>
                            <th onclick="location.href='<?= getSortUrl('tanggal_jatuh_tempo', $sort, $order) ?>'" 
                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors">
                                <div class="flex items-center space-x-1">
                                    <span>Jatuh Tempo</span>
                                    <?= getSortIcon('tanggal_jatuh_tempo', $sort, $order) ?>
                                </div>
                            </th>
                            <th onclick="location.href='<?= getSortUrl('jumlah_piutang', $sort, $order) ?>'" 
                                class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors">
                                <div class="flex items-center space-x-1">
                                    <span>Jumlah Piutang</span>
                                    <?= getSortIcon('jumlah_piutang', $sort, $order) ?>
                                </div>
                            </th>

                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sales</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($piutang_list as $piutang): ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div>
                                    <a href="transaksi-view.php?id=<?= $piutang['transaksi_id'] ?>" class="text-primary-600 hover:text-primary-800 font-semibold">
                                        <?= htmlspecialchars($piutang['nomor_transaksi']) ?>
                                    </a>
                                    <div class="text-xs text-gray-500"><?= date('d/m/Y', strtotime($piutang['tanggal_transaksi'])) ?></div>
                                </div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div>
                                    <div class="font-medium text-gray-900"><?= htmlspecialchars($piutang['nama_customer']) ?></div>
                                    <div class="text-sm text-gray-500"><?= htmlspecialchars($piutang['desa']) ?></div>
                                    <?php if ($piutang['no_hp']): ?>
                                    <div class="text-xs text-gray-500"><i class="fas fa-phone mr-1"></i><?= htmlspecialchars($piutang['no_hp']) ?></div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div>
                                    <div class="font-medium text-gray-900"><?= date('d/m/Y', strtotime($piutang['tanggal_jatuh_tempo'])) ?></div>
                                    <div><?= getJatuhTempoBadge($piutang['hari_tersisa'], $piutang['status']) ?></div>
                                </div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="font-semibold text-blue-600"><?= formatRupiah($piutang['jumlah_piutang']) ?></div>
                            </td>

                            <td class="px-4 py-3 whitespace-nowrap">
                                <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?= getStatusBadge($piutang['status']) ?>">
                                    <?= getStatusText($piutang['status']) ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900"><?= htmlspecialchars($piutang['sales_name']) ?></td>
                            <td class="px-4 py-3 whitespace-nowrap text-sm font-medium">
                                <div class="flex space-x-2">
                                    <a href="transaksi-view.php?id=<?= $piutang['transaksi_id'] ?>" 
                                       class="inline-flex items-center px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors" 
                                       title="Lihat Transaksi">
                                        <i class="fas fa-eye mr-1"></i>
                                        <span class="hidden sm:inline">Lihat</span>
                                    </a>
                                    
                                    <?php if (in_array($piutang['status'], ['belum_jatuh_tempo', 'mendekati_jatuh_tempo', 'terlambat']) && AuthStatic::hasRole(['admin', 'finance'])): ?>
                                    <button type="button" 
                                            class="inline-flex items-center px-3 py-1 bg-green-100 text-green-700 rounded-md hover:bg-green-200 transition-colors" 
                                            onclick="showPaymentForm(<?= $piutang['id'] ?>, '<?= htmlspecialchars($piutang['nomor_transaksi']) ?>', <?= $piutang['jumlah_piutang'] ?>)" 
                                            title="Catat Pembayaran">
                                        <i class="fas fa-money-bill-wave mr-1"></i>
                                        <span class="hidden sm:inline">Bayar</span>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="px-4 py-3 border-t border-gray-200">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="text-sm text-gray-700 mb-4 sm:mb-0">
                        Menampilkan <?= (($page - 1) * $limit) + 1 ?> sampai <?= min($page * $limit, $total_records) ?> dari <?= number_format($total_records) ?> hasil
                    </div>
                    <nav class="flex items-center space-x-2">
                        <?php if ($page > 1): ?>
                            <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>" 
                               class="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                                <i class="fas fa-chevron-left mr-1"></i> Sebelumnya
                            </a>
                        <?php endif; ?>
                        
                        <?php
                        $start_page = max(1, $page - 2);
                        $end_page = min($total_pages, $page + 2);
                        
                        for ($i = $start_page; $i <= $end_page; $i++):
                        ?>
                            <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" 
                               class="inline-flex items-center px-3 py-2 border <?= $i === $page ? 'border-primary-500 bg-primary-50 text-primary-600' : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50' ?> rounded-md text-sm font-medium transition-colors">
                                <?= $i ?>
                            </a>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>" 
                               class="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                                Selanjutnya <i class="fas fa-chevron-right ml-1"></i>
                            </a>
                        <?php endif; ?>
                    </nav>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>

        <!-- Hutang ke Vendor Section -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <div class="px-4 py-3 border-b border-gray-200 flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h3 class="text-lg font-semibold text-gray-900">Hutang ke Vendor</h3>
                    <p class="text-sm text-gray-600 mt-1"><?= number_format($hutang_stats['total_hutang'] ?? 0) ?> hutang aktif</p>
                </div>
                <div class="mt-4 sm:mt-0 flex items-center space-x-4">
                    <span class="text-sm text-gray-600">
                        Total: <span class="font-semibold text-red-600"><?= formatRupiah($hutang_stats['total_sisa_hutang'] ?? 0) ?></span>
                    </span>
                    <a href="pembelian.php" class="inline-flex items-center px-3 py-2 border border-primary-300 text-primary-700 text-sm font-medium rounded-lg hover:bg-primary-50 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-colors">
                        <i class="fas fa-eye mr-2"></i> Lihat Semua
                    </a>
                </div>
            </div>
            
            <?php if (empty($hutang_list)): ?>
            <div class="text-center py-12">
                <div class="w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-money-bill-wave text-gray-400 text-3xl"></i>
                </div>
                <h4 class="text-lg font-semibold text-gray-900 mb-2">Tidak ada hutang ditemukan</h4>
                <p class="text-gray-600 mb-6">Belum ada pembelian dengan sistem tempo yang menghasilkan hutang.</p>
                <button onclick="location.href='pembelian-add.php'" class="inline-flex items-center px-4 py-2 bg-primary-600 text-white text-sm font-medium rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-colors">
                    <i class="fas fa-plus mr-2"></i> Buat Pembelian Pertama
                </button>
            </div>
            <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">PO Number</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendor</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jatuh Tempo</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jumlah Hutang</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sisa Hutang</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($hutang_list as $hutang): ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div>
                                    <a href="pembelian-view.php?id=<?= $hutang['pembelian_id'] ?>" class="text-primary-600 hover:text-primary-800 font-semibold">
                                        <?= htmlspecialchars($hutang['nomor_po']) ?>
                                    </a>
                                    <div class="text-xs text-gray-500"><?= date('d/m/Y', strtotime($hutang['tanggal_pembelian'])) ?></div>
                                </div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div>
                                    <div class="font-medium text-gray-900"><?= htmlspecialchars($hutang['nama_vendor']) ?></div>
                                    <?php if ($hutang['nama_kontak']): ?>
                                    <div class="text-sm text-gray-500"><?= htmlspecialchars($hutang['nama_kontak']) ?></div>
                                    <?php endif; ?>
                                    <?php if ($hutang['no_hp']): ?>
                                    <div class="text-xs text-gray-500"><i class="fas fa-phone mr-1"></i><?= htmlspecialchars($hutang['no_hp']) ?></div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div>
                                    <div class="font-medium text-gray-900"><?= date('d/m/Y', strtotime($hutang['tanggal_jatuh_tempo'])) ?></div>
                                    <div><?= getJatuhTempoBadge($hutang['hari_tersisa'], $hutang['status']) ?></div>
                                </div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="font-semibold text-red-600"><?= formatRupiah($hutang['jumlah_hutang']) ?></div>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <?php if ($hutang['sisa_hutang'] > 0): ?>
                                    <div class="font-semibold text-red-600"><?= formatRupiah($hutang['sisa_hutang']) ?></div>
                                <?php else: ?>
                                    <span class="text-green-600 font-medium">Lunas</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap text-sm font-medium">
                                <div class="flex space-x-2">
                                    <a href="pembelian-view.php?id=<?= $hutang['pembelian_id'] ?>" 
                                       class="inline-flex items-center px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors" 
                                       title="Lihat Pembelian">
                                        <i class="fas fa-eye mr-1"></i>
                                        <span class="hidden sm:inline">Lihat</span>
                                    </a>
                                    <?php if ($hutang['sisa_hutang'] > 0): ?>
                                    <button 
                                        class="inline-flex items-center px-3 py-1 bg-green-100 text-green-700 rounded-md hover:bg-green-200 transition-colors" 
                                        onclick="showHutangPaymentForm(<?= $hutang['id'] ?>, '<?= htmlspecialchars($hutang['nomor_po']) ?>', <?= $hutang['sisa_hutang'] ?>)" 
                                        title="Catat Pembayaran">
                                    <i class="fas fa-money-bill-wave mr-1"></i>
                                    <span class="hidden sm:inline">Bayar</span>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div id="paymentModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900">Catat Pembayaran Piutang</h3>
                <button type="button" onclick="closePaymentModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="paymentForm">
                <input type="hidden" name="action" value="bayar">
                <input type="hidden" name="piutang_id" id="paymentPiutangId">
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Invoice:</label>
                        <p id="paymentInvoice" class="text-sm text-gray-900 font-semibold"></p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Sisa Piutang:</label>
                        <p id="paymentSisaPiutang" class="text-sm text-red-600 font-semibold"></p>
                    </div>
                    
                    <div>
                        <label for="jumlah_bayar" class="block text-sm font-medium text-gray-700 mb-1">
                            Jumlah Pembayaran <span class="text-red-500">*</span>
                        </label>
                        <div class="relative">
                            <span class="absolute left-3 top-2 text-gray-500">Rp</span>
                            <input type="number" class="w-full pl-8 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500" 
                                    id="hutang_jumlah_bayar" name="jumlah_bayar" min="1" step="1000" required>
                         </div>
                     </div>
                     
                     <div>
                         <label for="hutang_metode_pembayaran" class="block text-sm font-medium text-gray-700 mb-1">Metode Pembayaran</label>
                         <select class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500" 
                                 id="hutang_metode_pembayaran" name="metode_pembayaran">
                             <option value="tunai">Tunai</option>
                             <option value="transfer">Transfer Bank</option>
                             <option value="cek">Cek</option>
                             <option value="giro">Giro</option>
                         </select>
                     </div>
                     
                     <div>
                         <label for="hutang_keterangan" class="block text-sm font-medium text-gray-700 mb-1">Keterangan</label>
                         <textarea class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500" 
                                   id="hutang_keterangan" name="keterangan" rows="3" placeholder="Keterangan tambahan (opsional)"></textarea>
                     </div>
                 </div>
                 
                 <div class="flex justify-end space-x-3 mt-6">
                     <button type="button" onclick="closeHutangPaymentModal()" 
                             class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors">
                         Batal
                     </button>
                     <button type="submit" 
                             class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors">
                         <i class="fas fa-save mr-2"></i> Catat Pembayaran
                     </button>
                 </div>
             </form>
         </div>
     </div>
 </div>

<script>
    function showPaymentForm(piutangId, invoice, sisaPiutang) {
        document.getElementById('paymentPiutangId').value = piutangId;
        document.getElementById('paymentInvoice').textContent = invoice;
        document.getElementById('paymentSisaPiutang').textContent = 'Rp ' + formatRupiah(sisaPiutang);
        document.getElementById('jumlah_bayar').setAttribute('max', sisaPiutang);
        document.getElementById('jumlah_bayar').value = '';
        document.getElementById('metode_pembayaran').value = 'tunai';
        document.getElementById('keterangan').value = '';
        document.getElementById('paymentModal').classList.remove('hidden');
    }
    
    function closePaymentModal() {
        document.getElementById('paymentModal').classList.add('hidden');
    }
    
    function showHutangPaymentForm(hutangId, poNumber, sisaHutang) {
        document.getElementById('hutangPaymentId').value = hutangId;
        document.getElementById('hutangPaymentPO').textContent = poNumber;
        document.getElementById('hutangPaymentSisa').textContent = 'Rp ' + formatRupiah(sisaHutang);
        document.getElementById('hutang_jumlah_bayar').setAttribute('max', sisaHutang);
        document.getElementById('hutang_jumlah_bayar').value = '';
        document.getElementById('hutang_metode_pembayaran').value = 'tunai';
        document.getElementById('hutang_keterangan').value = '';
        document.getElementById('hutangPaymentModal').classList.remove('hidden');
    }
    
    function closeHutangPaymentModal() {
        document.getElementById('hutangPaymentModal').classList.add('hidden');
    }
    
    function formatRupiah(amount) {
        return new Intl.NumberFormat('id-ID').format(amount);
    }
    
    function exportData() {
        const params = new URLSearchParams(window.location.search);
        params.set('export', 'excel');
        window.location.href = '?' + params.toString();
    }
    
    // Auto-hide alerts
    setTimeout(function() {
        const alerts = document.querySelectorAll('.bg-green-50, .bg-red-50');
        alerts.forEach(alert => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);
    
    // Form validation
    document.getElementById('paymentForm').addEventListener('submit', function(e) {
        const jumlahBayar = parseFloat(document.getElementById('jumlah_bayar').value);
        const maxAmount = parseFloat(document.getElementById('jumlah_bayar').getAttribute('max'));
        
        if (jumlahBayar <= 0) {
            alert('Jumlah pembayaran harus lebih dari 0.');
            e.preventDefault();
            return;
        }
        
        if (jumlahBayar > maxAmount) {
            alert('Jumlah pembayaran tidak boleh melebihi sisa piutang.');
            e.preventDefault();
            return;
        }
    });
    
    // Close modal when clicking outside
    document.getElementById('paymentModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closePaymentModal();
        }
    });
</script>

<?php require_once 'layouts/footer.php'; ?>
