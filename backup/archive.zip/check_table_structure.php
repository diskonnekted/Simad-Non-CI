<?php
require_once 'config/database.php';

try {
    echo "Checking programmer_replies table structure:\n\n";
    
    $stmt = $pdo->query('DESCRIBE programmer_replies');
    while($row = $stmt->fetch()) {
        echo $row['Field'] . ' - ' . $row['Type'] . "\n";
    }
    
    echo "\nChecking admin_messages table structure:\n\n";
    
    $stmt = $pdo->query('DESCRIBE admin_messages');
    while($row = $stmt->fetch()) {
        echo $row['Field'] . ' - ' . $row['Type'] . "\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>